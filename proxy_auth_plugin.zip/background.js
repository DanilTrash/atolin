
                        var config = {
                                mode: "fixed_servers",
                                rules: {
                                singleProxy: {
                                    scheme: "http",
                                    host: "176.119.142.115",
                                    port: parseInt(11795)
                                },
                                bypassList: ["localhost"]
                                }
                            };
    
                        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    
                        function callbackFn(details) {
                            return {
                                authCredentials: {
                                    username: "daniltrashjob4448",
                                    password: "78d200"
                                }
                            };
                        }
    
                        chrome.webRequest.onAuthRequired.addListener(
                                    callbackFn,
                                    {urls: ["<all_urls>"]},
                                    ['blocking']
                        );
                        